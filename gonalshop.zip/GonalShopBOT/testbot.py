from aiogram import Bot, types
from aiogram.dispatcher import Dispatcher
from aiogram.dispatcher.filters import Text
from aiogram.utils import executor

bot = Bot(token="1889170052:AAGXusk_9GQSq03VVOTs1-Z43DCfu76kRhkк", parse_mode="html")
dp = Dispatcher(bot)

@dp.message_handler(commands=['start'])
async def start_message(message: types.Message):
    await bot.send_message(message.chat.id, "Привет {}!".format(message.from_user.username))

if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True) 