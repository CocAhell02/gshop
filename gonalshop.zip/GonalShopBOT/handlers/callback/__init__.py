from handlers.callback.admin_callback import dp
from handlers.callback.other_callback import dp
from handlers.callback.user_callback import dp

__all__ = ["dp"]
